const storageKey = 'dg-storeflow-state-v1';

const today = new Date();
const isoToday = today.toISOString().slice(0, 10);
const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const inventoryDate = '2026-06-25';
const inventoryLabel = 'June 25, 2026';
const scheduleStartDate = '2026-06-13';

const sevenDayWorkflow = [
  {
    day: 'Saturday',
    code: 'T+1',
    weekly: 'Hang ad signs at 7:00 p.m.',
    workflow: 'Stock truck core',
    freshTruck: 'P+4: Fill in overstock using FIFO. Ensure MAG is correct for remaining overstock. Check OHA of 3 items or less and PIA of milk/egg items.',
    nightly: 'Recovery'
  },
  {
    day: 'Sunday',
    code: 'T+2',
    weekly: '',
    workflow: 'Finish truck core',
    freshTruck: '',
    nightly: 'Recovery'
  },
  {
    day: 'Monday',
    code: 'T+3',
    weekly: 'Complete fresh damages/rotation and complete DG Connect.',
    workflow: 'Set and fill Seasonal G Sections. Set and fill MAG endcaps.',
    freshTruck: '',
    nightly: 'Recovery'
  },
  {
    day: 'Tuesday',
    code: 'T+4 / P-Day',
    weekly: 'Complete Compliance Tuesday.',
    workflow: 'Set POG sky shelves.',
    freshTruck: 'Prep deep recovery. Fill overstock using FIFO. Clean and sanitize coolers. Receive truck. Rotate nones as they arrive by priority: ice cream, milk, refrigerated, frozen.',
    nightly: 'Recovery'
  },
  {
    day: 'Wednesday',
    code: 'T+5',
    weekly: '',
    workflow: 'Backstock',
    freshTruck: '',
    nightly: 'Recovery'
  },
  {
    day: 'Thursday',
    code: 'T+6',
    weekly: 'Complete fresh damages/rotation.',
    workflow: 'Organize RR nones and tons. Complete dry damages.',
    freshTruck: '',
    nightly: 'Recovery'
  },
  {
    day: 'Friday',
    code: 'T-Day',
    weekly: '',
    workflow: 'Plan stocking. Receive truck. Stock toppers and totes.',
    freshTruck: '',
    nightly: 'Recovery'
  }
];

const complianceTuesdayTasks = [
  'Price changes: install core price change labels and hang clearance stickers.',
  'Complete nones and tons routine from the Store Business Center.',
  'Prioritize OTC sections.',
  'Product Rotation Alerts in HHT.',
  'Store Safety Walk: confirm register flash, fire extinguisher, and electrical panels are clear, unobstructed, and accessible.'
];

const dailyActivities = [
  'Complete all Daily Planner tasks for Front End, Receiving Room, and Sales Floor.',
  'Restock and rotate perishables.',
  'Fill Balance Impulse area by 9:00 a.m.',
  'Recover and clean first 30 feet all day.',
  'Deep recovery and stock FHB.',
  'Daily recovery from 5:00 p.m. to close for full store.'
];

const sampleState = {
  team: [
    { id: 't1', name: 'Chris', role: 'Store Manager', strength: 'workflow and compliance' },
    { id: 't2', name: 'Maya', role: 'Lead Sales Associate', strength: 'front end and training' },
    { id: 't3', name: 'Jordan', role: 'Sales Associate', strength: 'stocking and recovery' },
    { id: 't4', name: 'Devin', role: 'Sales Associate', strength: 'cooler and resets' }
  ],
  tasks: [
    {
      id: 'task-1',
      title: 'Review Compass updates and post shift priorities',
      category: 'compliance',
      priority: 'high',
      owner: 'Chris',
      due: isoToday,
      notes: 'Pull daily and weekly notes, then turn them into short position directions.',
      done: false
    },
    {
      id: 'task-2',
      title: 'Complete safety walk and temperature checks',
      category: 'compliance',
      priority: 'high',
      owner: 'Maya',
      due: isoToday,
      notes: 'Log issues before noon and assign fixes immediately.',
      done: false
    },
    {
      id: 'task-3',
      title: 'Finish CBL training follow-up',
      category: 'training',
      priority: 'medium',
      owner: 'Jordan',
      due: isoToday,
      notes: 'Check required modules and confirm completion before end of shift.',
      done: false
    },
    {
      id: 'task-4',
      title: 'Set POG sky shelves',
      category: 'planogram',
      priority: 'medium',
      owner: 'Devin',
      due: addDays(1),
      notes: 'Tuesday T+4 workflow: set POG sky shelves and confirm labels.',
      done: false
    },
    {
      id: 'task-5',
      title: 'Daily recovery 5:00 p.m. to close',
      category: 'reset',
      priority: 'low',
      owner: 'Chris',
      due: addDays(2),
      notes: 'Full store recovery every night; keep first 30 feet clean all day.',
      done: true
    },
    {
      id: 'task-6',
      title: 'Inventory prep: recover and clean first 30 feet',
      category: 'inventory',
      priority: 'high',
      owner: 'Maya',
      due: addDays(1),
      notes: 'Front end, checkout, seasonal entry, and high-traffic areas must stay faced and clean.',
      done: false
    },
    {
      id: 'task-7',
      title: 'Inventory prep: backroom and rolltainer count readiness',
      category: 'inventory',
      priority: 'high',
      owner: 'Jordan',
      due: addDays(2),
      notes: 'Stage, organize, and label problem areas so the team can count cleanly on inventory day.',
      done: false
    },
    {
      id: 'task-8',
      title: 'Inventory prep: damages, nones, tons, and dry damages',
      category: 'inventory',
      priority: 'high',
      owner: 'Chris',
      due: addDays(3),
      notes: 'Clear product that should not be counted as sellable and document follow-up.',
      done: false
    }
  ],
  schedule: buildSampleSchedule(),
  compassNotes: [
    { id: 'c1', title: '7-day setup', body: 'T-Day is Friday. P-Day is Tuesday. Pre-open stocking is yes. Dedicated delivery store is no.' },
    { id: 'c2', title: 'Daily reminder', body: 'Assign one owner per workflow task and check progress before shift change.' }
  ],
  messages: [
    { id: 'm1', from: 'Chris', body: 'Morning focus: compliance first, then training, then seasonal reset progress.', time: '7:12 AM' },
    { id: 'm2', from: 'Maya', body: 'Safety walk started. I will update once temperature checks are logged.', time: '8:06 AM' }
  ],
  photos: [],
  reminders: [
    { id: 'r1', title: 'Inventory countdown check', due: isoToday, owner: 'Chris', notes: 'Review open inventory prep tasks and assign each one before shift change.', done: false },
    { id: 'r2', title: 'Backroom readiness check', due: addDays(2), owner: 'Jordan', notes: 'Confirm rolltainers, totes, and staged freight are organized for counting.', done: false },
    { id: 'r3', title: 'Final sales floor recovery push', due: '2026-06-24', owner: 'Maya', notes: 'Full store recovery before inventory day on June 25, 2026.', done: false }
  ],
  timeEntries: [],
  activeTimer: null
};

let state = loadState();
let activeFilter = 'all';
let activeScheduleWeek = 0;

const views = {
  dashboard: document.querySelector('#dashboardView'),
  tasks: document.querySelector('#tasksView'),
  inventory: document.querySelector('#inventoryView'),
  schedule: document.querySelector('#scheduleView'),
  compass: document.querySelector('#compassView'),
  photos: document.querySelector('#photosView'),
  team: document.querySelector('#teamView')
};

const pageTitles = {
  dashboard: 'Daily Command Center',
  tasks: 'Task Board',
  inventory: 'Inventory Prep',
  schedule: 'Schedule and Position Direction',
  compass: 'Compass and 7-Day Workflow',
  photos: 'Photo Intake',
  team: 'Team Communication'
};

document.querySelector('#todayLabel').textContent = `${dayNames[today.getDay()]}, ${today.toLocaleDateString()}`;
document.querySelector('#taskDue').value = isoToday;

bindEvents();
render();
registerServiceWorker();

function addDays(days) {
  const date = new Date();
  date.setDate(date.getDate() + days);
  return date.toISOString().slice(0, 10);
}

function addDaysToDate(value, days) {
  const date = new Date(`${value}T12:00:00`);
  date.setDate(date.getDate() + days);
  return date.toISOString().slice(0, 10);
}

function buildSampleSchedule() {
  const weekOne = [
    ['2026-06-13', 'Alicia T.', 'Sales Associate', '06:00', '15:00', 'Front end, recovery, and customer coverage'],
    ['2026-06-13', 'Chris C.', 'Store Manager', '06:00', '15:00', 'Manager coverage, workflow, and truck direction'],
    ['2026-06-13', 'Elvis J.', 'Sales Associate', '06:00', '15:00', 'Stocking and recovery'],
    ['2026-06-13', 'Louis C.', 'Sales Associate', '06:00', '15:00', 'Core freight and sales floor support'],
    ['2026-06-13', 'Blaire M.', 'Sales Associate', '08:00', '16:00', 'Register, totes, and recovery'],
    ['2026-06-14', 'Blaire M.', 'Sales Associate', '06:00', '15:00', 'Front end and stocking'],
    ['2026-06-14', 'Chris C.', 'Store Manager', '06:00', '15:00', 'Manager coverage and daily planner'],
    ['2026-06-14', 'Louis C.', 'Sales Associate', '06:00', '15:00', 'Stocking support'],
    ['2026-06-14', 'Carlton R.', 'Sales Associate', '15:15', '23:15', 'Closing recovery'],
    ['2026-06-15', 'Sarah I.', 'Assistant Store Manager', '07:45', '15:15', 'Opening manager and compliance'],
    ['2026-06-15', 'Jazmin G.', 'Sales Associate', '08:00', '15:00', 'Register and recovery'],
    ['2026-06-15', 'Blaire M.', 'Sales Associate', '15:15', '23:15', 'Closing coverage'],
    ['2026-06-15', 'Chris C.', 'Store Manager', '15:15', '23:15', 'Closing manager and inventory prep'],
    ['2026-06-16', 'Sarah I.', 'Assistant Store Manager', '06:00', '14:00', 'P-Day, fresh truck, and workflow'],
    ['2026-06-16', 'Alicia T.', 'Sales Associate', '08:00', '15:00', 'Front end and Compliance Tuesday support'],
    ['2026-06-16', 'Carlton R.', 'Sales Associate', '08:00', '13:30', 'Recovery and sky shelves'],
    ['2026-06-16', 'Jazmin G.', 'Sales Associate', '08:00', '15:00', 'Register and planogram support'],
    ['2026-06-16', 'Chris C.', 'Store Manager', '13:15', '17:30', 'Inventory prep and follow-up'],
    ['2026-06-16', 'Elvis J.', 'Sales Associate', '15:15', '23:15', 'Closing recovery'],
    ['2026-06-17', 'Sarah I.', 'Assistant Store Manager', '07:45', '15:00', 'Backstock and opening direction'],
    ['2026-06-17', 'Chris C.', 'Store Manager', '08:00', '15:00', 'Inventory prep and manager coverage'],
    ['2026-06-17', 'Elvis J.', 'Sales Associate', '15:15', '23:15', 'Closing recovery'],
    ['2026-06-17', 'Blaire M.', 'Sales Associate', '15:15', '23:15', 'Closing coverage'],
    ['2026-06-18', 'Chris C.', 'Store Manager', '06:00', '15:00', 'Fresh damages, rotation, and manager coverage'],
    ['2026-06-18', 'Sarah I.', 'Assistant Store Manager', '08:00', '13:00', 'Front end and inventory prep'],
    ['2026-06-18', 'Carlton R.', 'Sales Associate', '13:15', '16:30', 'Recovery and stock support'],
    ['2026-06-18', 'Asael H.', 'Sales Associate', '15:15', '23:15', 'Closing coverage'],
    ['2026-06-18', 'Elvis J.', 'Sales Associate', '15:15', '23:15', 'Closing recovery'],
    ['2026-06-19', 'Chris C.', 'Store Manager', '07:45', '16:45', 'T-Day planning, receive truck, and toppers/totes'],
    ['2026-06-19', 'Alicia T.', 'Sales Associate', '08:00', '15:00', 'Truck and front end support'],
    ['2026-06-19', 'Jazmin G.', 'Sales Associate', '08:00', '15:00', 'Register and truck support'],
    ['2026-06-19', 'Sarah I.', 'Assistant Store Manager', '08:00', '14:00', 'Inventory prep and floor recovery'],
    ['2026-06-19', 'Carlton R.', 'Sales Associate', '15:15', '23:15', 'Closing recovery'],
    ['2026-06-19', 'Jeff H.', 'Sales Associate', '15:15', '23:15', 'Closing coverage']
  ];

  const weekTwo = weekOne.map(([date, name, position, start, end, direction], index) => [
    addDaysToDate(date, 7),
    name,
    position,
    start,
    end,
    index % 3 === 0 ? 'Inventory week prep, recovery, and count readiness' : direction
  ]);

  return [...weekOne, ...weekTwo].map(([date, name, position, start, end, direction], index) => ({
    id: `s${index + 1}`,
    date,
    name,
    position,
    start,
    end,
    direction
  }));
}

function normalizeSchedule(schedule) {
  return schedule.map((shift, index) => {
    if (shift.date && shift.start && shift.end) return shift;
    const [start, end] = parseShiftTime(shift.time || '9:00 AM - 1:00 PM');
    return {
      id: shift.id || `s-normalized-${index}`,
      date: shift.date || isoToday,
      name: shift.name,
      position: shift.position,
      start,
      end,
      direction: shift.direction || 'Add shift direction based on store needs.'
    };
  });
}

function parseShiftTime(value) {
  const [startLabel, endLabel] = value.split('-').map((part) => part.trim());
  return [toTwentyFourHour(startLabel), toTwentyFourHour(endLabel)];
}

function toTwentyFourHour(value) {
  const match = value.match(/(\d{1,2}):(\d{2})\s*(AM|PM)/i);
  if (!match) return '09:00';
  let hour = Number(match[1]);
  const minute = match[2];
  const marker = match[3].toUpperCase();
  if (marker === 'PM' && hour !== 12) hour += 12;
  if (marker === 'AM' && hour === 12) hour = 0;
  return `${String(hour).padStart(2, '0')}:${minute}`;
}

function loadState() {
  const saved = localStorage.getItem(storageKey);
  if (!saved) return structuredClone(sampleState);

  try {
    return normalizeState(JSON.parse(saved));
  } catch {
    return structuredClone(sampleState);
  }
}

function normalizeState(savedState) {
  return {
    ...structuredClone(sampleState),
    ...savedState,
    team: savedState.team || sampleState.team,
    tasks: savedState.tasks || sampleState.tasks,
    schedule: normalizeSchedule(savedState.schedule || sampleState.schedule),
    compassNotes: savedState.compassNotes || sampleState.compassNotes,
    messages: savedState.messages || sampleState.messages,
    photos: savedState.photos || [],
    reminders: savedState.reminders || sampleState.reminders,
    timeEntries: savedState.timeEntries || [],
    activeTimer: savedState.activeTimer || null
  };
}

function saveState() {
  localStorage.setItem(storageKey, JSON.stringify(state));
}

function registerServiceWorker() {
  if (!('serviceWorker' in navigator)) return;
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./service-worker.js').catch(() => {});
  });
}

function bindEvents() {
  document.querySelectorAll('.nav-item').forEach((button) => {
    button.addEventListener('click', () => setView(button.dataset.view));
  });

  document.querySelectorAll('[data-view-jump]').forEach((button) => {
    button.addEventListener('click', () => setView(button.dataset.viewJump));
  });

  document.querySelectorAll('[data-filter]').forEach((button) => {
    button.addEventListener('click', () => {
      activeFilter = button.dataset.filter;
      document.querySelectorAll('[data-filter]').forEach((chip) => chip.classList.remove('active'));
      button.classList.add('active');
      renderTasks();
    });
  });

  document.querySelectorAll('[data-schedule-week]').forEach((button) => {
    button.addEventListener('click', () => {
      activeScheduleWeek = Number(button.dataset.scheduleWeek);
      document.querySelectorAll('[data-schedule-week]').forEach((tab) => tab.classList.remove('active'));
      button.classList.add('active');
      renderSchedule();
    });
  });

  document.querySelector('#openTaskModal').addEventListener('click', openTaskDialog);
  document.querySelector('#refreshSuggestions').addEventListener('click', renderSuggestions);
  document.querySelector('#seedButton').addEventListener('click', () => {
    state = structuredClone(sampleState);
    saveState();
    render();
  });

  document.querySelector('#taskForm').addEventListener('submit', (event) => {
    const submitter = event.submitter;
    if (submitter?.value === 'cancel') return;
    event.preventDefault();
    createTask();
  });

  document.querySelector('#messageForm').addEventListener('submit', (event) => {
    event.preventDefault();
    const input = document.querySelector('#messageInput');
    const body = input.value.trim();
    if (!body) return;
    state.messages.unshift({
      id: crypto.randomUUID(),
      from: 'Chris',
      body,
      time: new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })
    });
    input.value = '';
    saveState();
    renderMessages();
  });

  document.querySelector('#addShift').addEventListener('click', () => {
    const next = state.team[state.schedule.length % state.team.length];
    const date = addDaysToDate(scheduleStartDate, activeScheduleWeek * 7);
    state.schedule.push({
      id: crypto.randomUUID(),
      name: next.name,
      position: 'Assigned Coverage',
      date,
      start: '09:00',
      end: '13:00',
      direction: 'Add shift direction based on store needs.'
    });
    saveState();
    renderSchedule();
  });

  document.querySelector('#addCompassNote').addEventListener('click', () => {
    state.compassNotes.unshift({
      id: crypto.randomUUID(),
      title: 'New Compass note',
      body: 'Paste the key update here, then convert it into assigned tasks.'
    });
    saveState();
    renderCompass();
  });

  document.querySelector('#photoForm').addEventListener('submit', handlePhotoUpload);
  document.querySelector('#clearPhotos').addEventListener('click', () => {
    state.photos = [];
    saveState();
    render();
  });

  document.querySelector('#addReminder').addEventListener('click', addInventoryReminder);
  document.querySelector('#addInventoryPlan').addEventListener('click', addInventoryPrepPlan);
}

function setView(viewName) {
  Object.values(views).forEach((view) => view.classList.remove('active'));
  views[viewName].classList.add('active');
  document.querySelectorAll('.nav-item').forEach((button) => {
    button.classList.toggle('active', button.dataset.view === viewName);
  });
  document.querySelector('#pageTitle').textContent = pageTitles[viewName];
}

function openTaskDialog() {
  const ownerSelect = document.querySelector('#taskOwner');
  ownerSelect.innerHTML = state.team.map((member) => `<option value="${member.name}">${member.name}</option>`).join('');
  document.querySelector('#taskDue').value = isoToday;
  document.querySelector('#taskModal').showModal();
}

function populatePhotoOwners() {
  document.querySelector('#photoOwner').innerHTML = state.team
    .map((member) => `<option value="${member.name}">${member.name}</option>`)
    .join('');
}

function createTask() {
  state.tasks.unshift({
    id: crypto.randomUUID(),
    title: document.querySelector('#taskTitle').value.trim(),
    category: document.querySelector('#taskCategory').value,
    priority: document.querySelector('#taskPriority').value,
    owner: document.querySelector('#taskOwner').value,
    due: document.querySelector('#taskDue').value,
    notes: document.querySelector('#taskNotes').value.trim(),
    done: false
  });
  document.querySelector('#taskForm').reset();
  document.querySelector('#taskModal').close();
  saveState();
  render();
}

function addInventoryReminder() {
  state.reminders.unshift({
    id: crypto.randomUUID(),
    title: 'Inventory prep reminder',
    due: isoToday,
    owner: state.team[0]?.name || 'Chris',
    notes: 'Add what needs checked before inventory on June 25, 2026.',
    done: false
  });
  saveState();
  renderInventory();
}

function addInventoryPrepPlan() {
  const plans = [
    ['Inventory prep: verify top stock and sky shelves', 'Check labels, overstock, and shelf location issues before final recovery.'],
    ['Inventory prep: clean receiving room paths', 'Make count access easy and remove blockers from backroom work areas.'],
    ['Inventory prep: scan problem outs and shelf label issues', 'Use photos and task notes to point the team to exact aisles.']
  ];
  const [title, notes] = plans[state.tasks.filter((task) => task.category === 'inventory').length % plans.length];
  state.tasks.unshift({
    id: crypto.randomUUID(),
    title,
    category: 'inventory',
    priority: 'high',
    owner: state.team[state.tasks.length % state.team.length]?.name || 'Chris',
    due: isoToday,
    notes,
    done: false
  });
  saveState();
  render();
}

async function handlePhotoUpload(event) {
  event.preventDefault();
  const files = [...document.querySelector('#photoInput').files];
  if (!files.length) return;

  const category = document.querySelector('#photoCategory').value;
  const owner = document.querySelector('#photoOwner').value;
  const instruction = document.querySelector('#photoInstruction').value.trim() || 'Review this photo and follow up with the team.';
  const shouldCreateTask = document.querySelector('#photoCreateTask').checked;

  for (const file of files) {
    const photo = {
      id: crypto.randomUUID(),
      name: file.name,
      category,
      owner,
      instruction,
      createdAt: new Date().toISOString(),
      dataUrl: await resizeImageFile(file)
    };
    state.photos.unshift(photo);

    if (shouldCreateTask) {
      state.tasks.unshift({
        id: crypto.randomUUID(),
        title: `Photo follow-up: ${capitalize(category)}`,
        category: category === 'compass' ? 'compliance' : category,
        priority: ['compliance', 'planogram', 'truck'].includes(category) ? 'high' : 'medium',
        owner,
        due: isoToday,
        notes: instruction,
        photoId: photo.id,
        done: false
      });

      state.messages.unshift({
        id: crypto.randomUUID(),
        from: 'Chris',
        body: `${owner}: ${instruction}`,
        time: new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }),
        photoId: photo.id
      });
    }
  }

  document.querySelector('#photoForm').reset();
  saveState();
  render();
}

function resizeImageFile(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = reject;
    reader.onload = () => {
      const image = new Image();
      image.onerror = reject;
      image.onload = () => {
        const maxSize = 1200;
        const scale = Math.min(1, maxSize / Math.max(image.width, image.height));
        const canvas = document.createElement('canvas');
        canvas.width = Math.round(image.width * scale);
        canvas.height = Math.round(image.height * scale);
        const context = canvas.getContext('2d');
        context.drawImage(image, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL('image/jpeg', 0.78));
      };
      image.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}

function render() {
  renderMetrics();
  renderTasks();
  renderInventory();
  renderSuggestions();
  renderSchedule();
  renderCompass();
  renderPhotos();
  renderMessages();
  renderRoster();
  renderDailyBrief();
  populatePhotoOwners();
}

function renderDailyBrief() {
  const todayWorkflow = getWorkflowForToday();
  const daysLeft = getDaysUntilInventory();
  const dueToday = state.tasks.filter((task) => task.due <= isoToday && !task.done);
  const high = dueToday.filter((task) => task.priority === 'high');
  const brief = high.length
    ? `${high.length} high-priority item${high.length === 1 ? '' : 's'} need attention today. Inventory is ${daysLeft} day${daysLeft === 1 ? '' : 's'} away on ${inventoryLabel}. Today's workflow is ${todayWorkflow.code}: ${todayWorkflow.workflow}`
    : `Inventory is ${daysLeft} day${daysLeft === 1 ? '' : 's'} away on ${inventoryLabel}. Today's workflow is ${todayWorkflow.code}: ${todayWorkflow.workflow} Keep the team moving through prep, recovery, and customer coverage.`;
  document.querySelector('#dailyBrief').textContent = brief;
  document.querySelector('#storeHealthPill').textContent = high.length > 2 ? 'At Risk' : 'On Track';
}

function renderMetrics() {
  const total = state.tasks.length;
  const done = state.tasks.filter((task) => task.done).length;
  const dueToday = state.tasks.filter((task) => task.due <= isoToday && !task.done).length;
  const inventoryOpen = state.tasks.filter((task) => task.category === 'inventory' && !task.done).length;

  const metrics = [
    ['Inventory In', `${getDaysUntilInventory()} days`],
    ['Due Today', dueToday],
    ['Inventory Open', inventoryOpen],
    ['Productive Time', formatMinutes(getTotalMinutes())]
  ];

  document.querySelector('#metricGrid').innerHTML = metrics
    .map(([label, value]) => `<article class="metric"><span>${label}</span><strong>${value}</strong></article>`)
    .join('');
}

function renderTasks() {
  const sorted = [...state.tasks].sort((a, b) => {
    const priorityScore = { high: 0, medium: 1, low: 2 };
    return priorityScore[a.priority] - priorityScore[b.priority] || a.due.localeCompare(b.due);
  });

  const filtered = activeFilter === 'all' ? sorted : sorted.filter((task) => task.category === activeFilter);
  document.querySelector('#taskBoard').innerHTML = filtered.map(taskTemplate).join('');
  document.querySelector('#priorityTaskList').innerHTML = sorted.filter((task) => !task.done).slice(0, 4).map(taskTemplate).join('');
  bindTaskControls(document.querySelector('#tasksView'));
  bindTaskControls(document.querySelector('#dashboardView'));
}

function bindTaskControls(scope) {
  scope.querySelectorAll('[data-task-toggle]').forEach((checkbox) => {
    checkbox.addEventListener('change', () => {
      const task = state.tasks.find((item) => item.id === checkbox.dataset.taskToggle);
      task.done = checkbox.checked;
      if (task.done && state.activeTimer?.taskId === task.id) {
        stopTimer();
      }
      saveState();
      render();
    });
  });

  scope.querySelectorAll('[data-start-timer]').forEach((button) => {
    button.addEventListener('click', () => startTimer(button.dataset.startTimer));
  });

  scope.querySelectorAll('[data-stop-timer]').forEach((button) => {
    button.addEventListener('click', stopTimer);
  });

  scope.querySelectorAll('[data-add-time]').forEach((button) => {
    button.addEventListener('click', () => addManualTime(button.dataset.addTime, 15));
  });
}

function taskTemplate(task) {
  const photo = findPhoto(task.photoId);
  const minutes = getTaskMinutes(task.id);
  const isActive = state.activeTimer?.taskId === task.id;
  return `
    <article class="task-card ${task.done ? 'done' : ''}">
      <input type="checkbox" ${task.done ? 'checked' : ''} data-task-toggle="${task.id}" aria-label="Complete ${escapeHtml(task.title)}">
      <div>
        <p class="task-title">${escapeHtml(task.title)}</p>
        <div class="task-meta">${capitalize(task.category)} · ${escapeHtml(task.owner)} · due ${formatDue(task.due)}</div>
        <div class="subtle">${escapeHtml(task.notes || 'No notes added.')}</div>
        ${photo ? photoThumb(photo) : ''}
        <div class="task-actions">
          <span class="time-chip">${formatMinutes(minutes)} logged</span>
          ${
            isActive
              ? `<button class="secondary-button small-button" data-stop-timer="${task.id}" type="button">Stop</button>`
              : `<button class="secondary-button small-button" data-start-timer="${task.id}" type="button">Start</button>`
          }
          <button class="secondary-button small-button" data-add-time="${task.id}" type="button">+15 min</button>
        </div>
      </div>
      <span class="badge ${task.priority}">${capitalize(task.priority)}</span>
    </article>
  `;
}

function startTimer(taskId) {
  if (state.activeTimer?.taskId === taskId) return;
  if (state.activeTimer) stopTimer();
  state.activeTimer = {
    taskId,
    startedAt: new Date().toISOString()
  };
  saveState();
  render();
}

function stopTimer() {
  if (!state.activeTimer) return;
  const task = state.tasks.find((item) => item.id === state.activeTimer.taskId);
  const started = new Date(state.activeTimer.startedAt);
  const minutes = Math.max(1, Math.round((Date.now() - started.getTime()) / 60000));
  state.timeEntries.unshift({
    id: crypto.randomUUID(),
    taskId: state.activeTimer.taskId,
    taskTitle: task?.title || 'Unknown task',
    owner: task?.owner || 'Unassigned',
    category: task?.category || 'general',
    minutes,
    createdAt: new Date().toISOString()
  });
  state.activeTimer = null;
  saveState();
  render();
}

function addManualTime(taskId, minutes) {
  const task = state.tasks.find((item) => item.id === taskId);
  if (!task) return;
  state.timeEntries.unshift({
    id: crypto.randomUUID(),
    taskId,
    taskTitle: task.title,
    owner: task.owner,
    category: task.category,
    minutes,
    createdAt: new Date().toISOString()
  });
  saveState();
  render();
}

function renderSuggestions() {
  const todayWorkflow = getWorkflowForToday();
  const open = state.tasks.filter((task) => !task.done);
  const highDue = open.filter((task) => task.priority === 'high' && task.due <= isoToday);
  const planograms = open.filter((task) => ['planogram', 'reset'].includes(task.category));
  const training = open.filter((task) => task.category === 'training');
  const inventory = open.filter((task) => task.category === 'inventory');

  const suggestions = [
    highDue.length
      ? `Move ${highDue[0].owner} to "${highDue[0].title}" first and check back within 60 minutes.`
      : 'Use the first hour to verify compliance logs before the store gets busy.',
    planograms.length
      ? `Stage labels and discontinued product for ${planograms[0].owner} before the reset starts.`
      : 'Use recovery time to scan for missing labels, empty pegs, and damaged product.',
    training.length
      ? `Protect a quiet block for ${training[0].owner} to finish training without register interruptions.`
      : 'Ask each shift lead for one blocker before shift change and turn it into a task.',
    inventory.length
      ? `Inventory is ${getDaysUntilInventory()} days away. Put tracked time on "${inventory[0].title}" today.`
      : 'Use +15 min logs on prep work so you can see where productive time is going.',
    `Today is ${todayWorkflow.day} ${todayWorkflow.code}: ${todayWorkflow.workflow}`
  ];

  document.querySelector('#suggestionList').innerHTML = suggestions
    .map((text) => `<article class="suggestion">${escapeHtml(text)}</article>`)
    .join('');
}

function getWorkflowForToday() {
  return sevenDayWorkflow.find((item) => item.day === dayNames[today.getDay()]) || sevenDayWorkflow[0];
}

function renderInventory() {
  const daysLeft = getDaysUntilInventory();
  const inventoryTasks = state.tasks
    .filter((task) => task.category === 'inventory')
    .sort((a, b) => Number(a.done) - Number(b.done) || a.due.localeCompare(b.due));
  const openInventory = inventoryTasks.filter((task) => !task.done).length;
  const dueReminders = state.reminders.filter((reminder) => reminder.due <= isoToday && !reminder.done).length;

  document.querySelector('#inventorySummary').innerHTML = `
    <article class="inventory-countdown">
      <span class="store-label">Inventory date</span>
      <strong>${inventoryLabel}</strong>
      <p>${daysLeft} day${daysLeft === 1 ? '' : 's'} left. ${openInventory} inventory prep task${openInventory === 1 ? '' : 's'} still open. ${dueReminders} reminder${dueReminders === 1 ? '' : 's'} due now.</p>
    </article>
  `;

  document.querySelector('#inventoryTaskList').innerHTML = inventoryTasks.length
    ? inventoryTasks.map(taskTemplate).join('')
    : '<div class="empty-state">No inventory prep tasks yet. Add a prep plan to start tracking readiness.</div>';

  document.querySelector('#reminderList').innerHTML = state.reminders
    .sort((a, b) => Number(a.done) - Number(b.done) || a.due.localeCompare(b.due))
    .map((reminder) => `
      <article class="reminder ${reminder.done ? 'done' : ''}">
        <input type="checkbox" ${reminder.done ? 'checked' : ''} data-reminder-toggle="${reminder.id}" aria-label="Complete ${escapeHtml(reminder.title)}">
        <div>
          <strong>${escapeHtml(reminder.title)}</strong>
          <div class="task-meta">${escapeHtml(reminder.owner)} · due ${formatDue(reminder.due)}</div>
          <p class="subtle">${escapeHtml(reminder.notes)}</p>
        </div>
      </article>
    `)
    .join('');

  document.querySelectorAll('[data-reminder-toggle]').forEach((checkbox) => {
    checkbox.addEventListener('change', () => {
      const reminder = state.reminders.find((item) => item.id === checkbox.dataset.reminderToggle);
      reminder.done = checkbox.checked;
      saveState();
      renderInventory();
    });
  });

  bindTaskControls(document.querySelector('#inventoryView'));
  renderTimeSummary();
}

function renderTimeSummary() {
  const categoryTotals = getMinutesBy('category');
  const ownerTotals = getMinutesBy('owner');
  const topCategories = Object.entries(categoryTotals)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 4);
  const topOwners = Object.entries(ownerTotals)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 4);

  document.querySelector('#timeSummary').innerHTML = `
    <div class="time-stat"><span>Total logged</span><strong>${formatMinutes(getTotalMinutes())}</strong></div>
    <div class="time-stat"><span>Inventory prep</span><strong>${formatMinutes(categoryTotals.inventory || 0)}</strong></div>
    <div class="time-stat"><span>Active timer</span><strong>${state.activeTimer ? 'Running' : 'None'}</strong></div>
    <div class="time-breakdown">
      <strong>By category</strong>
      ${topCategories.map(([label, minutes]) => `<p>${escapeHtml(capitalize(label))}: ${formatMinutes(minutes)}</p>`).join('') || '<p>No time logged yet.</p>'}
    </div>
    <div class="time-breakdown">
      <strong>By person</strong>
      ${topOwners.map(([label, minutes]) => `<p>${escapeHtml(label)}: ${formatMinutes(minutes)}</p>`).join('') || '<p>No time logged yet.</p>'}
    </div>
  `;

  document.querySelector('#timeLog').innerHTML = state.timeEntries.slice(0, 8)
    .map((entry) => `
      <article class="time-entry">
        <strong>${escapeHtml(entry.taskTitle)}</strong>
        <div class="task-meta">${escapeHtml(entry.owner)} · ${escapeHtml(capitalize(entry.category))} · ${formatMinutes(entry.minutes)}</div>
      </article>
    `)
    .join('');
}

function renderPhotos() {
  const container = document.querySelector('#photoGrid');
  if (!state.photos.length) {
    container.innerHTML = '<div class="empty-state">Upload Compass screenshots, planogram photos, compliance notes, backroom issues, or recovery photos to coordinate follow-up.</div>';
    return;
  }

  container.innerHTML = state.photos
    .map((photo) => `
      <article class="photo-card">
        <img src="${photo.dataUrl}" alt="${escapeHtml(photo.name)}">
        <div class="photo-body">
          <div class="photo-title">
            <strong>${escapeHtml(capitalize(photo.category))}</strong>
            <span class="badge medium">${escapeHtml(photo.owner)}</span>
          </div>
          <p class="subtle">${escapeHtml(photo.instruction)}</p>
          <div class="photo-actions">
            <button class="secondary-button" data-photo-task="${photo.id}" type="button">Task</button>
            <button class="secondary-button" data-photo-message="${photo.id}" type="button">Message</button>
          </div>
        </div>
      </article>
    `)
    .join('');

  document.querySelectorAll('[data-photo-task]').forEach((button) => {
    button.addEventListener('click', () => createTaskFromPhoto(button.dataset.photoTask));
  });

  document.querySelectorAll('[data-photo-message]').forEach((button) => {
    button.addEventListener('click', () => createMessageFromPhoto(button.dataset.photoMessage));
  });
}

function getDaysUntilInventory() {
  const target = new Date(`${inventoryDate}T12:00:00`);
  const current = new Date(`${isoToday}T12:00:00`);
  return Math.max(0, Math.ceil((target - current) / 86400000));
}

function getTaskMinutes(taskId) {
  const logged = state.timeEntries
    .filter((entry) => entry.taskId === taskId)
    .reduce((sum, entry) => sum + entry.minutes, 0);
  if (state.activeTimer?.taskId !== taskId) return logged;
  const running = Math.max(0, Math.floor((Date.now() - new Date(state.activeTimer.startedAt).getTime()) / 60000));
  return logged + running;
}

function getTotalMinutes() {
  return state.tasks.reduce((sum, task) => sum + getTaskMinutes(task.id), 0);
}

function getMinutesBy(field) {
  return state.timeEntries.reduce((totals, entry) => {
    const key = entry[field] || 'unknown';
    totals[key] = (totals[key] || 0) + entry.minutes;
    return totals;
  }, {});
}

function formatMinutes(minutes) {
  if (!minutes) return '0m';
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  if (!hours) return `${mins}m`;
  if (!mins) return `${hours}h`;
  return `${hours}h ${mins}m`;
}

function createTaskFromPhoto(photoId) {
  const photo = findPhoto(photoId);
  if (!photo) return;
  state.tasks.unshift({
    id: crypto.randomUUID(),
    title: `Photo follow-up: ${capitalize(photo.category)}`,
    category: photo.category === 'compass' ? 'compliance' : photo.category,
    priority: ['compliance', 'planogram', 'truck'].includes(photo.category) ? 'high' : 'medium',
    owner: photo.owner,
    due: isoToday,
    notes: photo.instruction,
    photoId: photo.id,
    done: false
  });
  saveState();
  render();
  setView('tasks');
}

function createMessageFromPhoto(photoId) {
  const photo = findPhoto(photoId);
  if (!photo) return;
  state.messages.unshift({
    id: crypto.randomUUID(),
    from: 'Chris',
    body: `${photo.owner}: ${photo.instruction}`,
    time: new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }),
    photoId: photo.id
  });
  saveState();
  render();
  setView('team');
}

function findPhoto(photoId) {
  if (!photoId) return null;
  return state.photos.find((photo) => photo.id === photoId) || null;
}

function photoThumb(photo) {
  return `<img class="inline-photo" src="${photo.dataUrl}" alt="${escapeHtml(photo.name)}">`;
}

function renderSchedule() {
  const weekDates = getScheduleWeekDates(activeScheduleWeek);
  const weekShifts = state.schedule.filter((shift) => weekDates.includes(shift.date));
  const totalHours = weekShifts.reduce((sum, shift) => sum + getShiftHours(shift), 0);
  const people = new Set(weekShifts.map((shift) => shift.name)).size;

  document.querySelector('#scheduleStats').innerHTML = `
    <article class="schedule-stat"><span>Week</span><strong>${formatDateShort(weekDates[0])} - ${formatDateShort(weekDates[6])}</strong></article>
    <article class="schedule-stat"><span>Scheduled</span><strong>${totalHours.toFixed(2)} hrs</strong></article>
    <article class="schedule-stat"><span>Team Members</span><strong>${people}</strong></article>
  `;

  document.querySelector('#scheduleGrid').innerHTML = weekDates
    .map((date) => {
      const shifts = state.schedule
        .filter((shift) => shift.date === date)
        .sort((a, b) => a.start.localeCompare(b.start));
      const dayHours = shifts.reduce((sum, shift) => sum + getShiftHours(shift), 0);
      return `
        <article class="schedule-day ${date === isoToday ? 'today' : ''}">
          <div class="schedule-day-head">
            <strong>${dayNames[new Date(`${date}T12:00:00`).getDay()]}</strong>
            <span>${formatDateShort(date)}</span>
            <small>${dayHours.toFixed(2)} hrs · ${shifts.length} TM${shifts.length === 1 ? '' : 's'}</small>
          </div>
          <div class="schedule-shifts">
            ${
              shifts.length
                ? shifts.map(scheduleShiftTemplate).join('')
                : '<div class="empty-state small-empty">No shifts</div>'
            }
          </div>
        </article>
      `;
    })
    .join('');

  const todayShifts = state.schedule
    .filter((shift) => shift.date === isoToday)
    .sort((a, b) => a.start.localeCompare(b.start));

  document.querySelector('#scheduleList').innerHTML = todayShifts.length
    ? todayShifts.map((shift) => `
        <article class="shift">
          <div>
            <strong>${escapeHtml(shift.name)}</strong>
            <div class="task-meta">${escapeHtml(shift.position)} · ${formatTimeRange(shift)}</div>
            <div class="subtle">${escapeHtml(shift.direction)}</div>
          </div>
          <span class="badge low">${getShiftHours(shift).toFixed(1)}h</span>
        </article>
      `).join('')
    : '<div class="empty-state">No shifts are scheduled for today.</div>';

  const todayDirection = state.schedule.filter((shift) => shift.date === isoToday);
  document.querySelector('#positionList').innerHTML = todayDirection.length
    ? todayDirection
    .map((shift) => `
      <article class="position-card">
        <strong>${escapeHtml(shift.position)}</strong>
        <p class="subtle">${escapeHtml(shift.name)}: ${escapeHtml(shift.direction)}</p>
      </article>
    `)
    .join('')
    : '<div class="empty-state">No position direction is scheduled for today.</div>';
}

function scheduleShiftTemplate(shift) {
  const initials = shift.name
    .split(' ')
    .map((part) => part[0])
    .join('')
    .slice(0, 2)
    .toUpperCase();
  return `
    <div class="schedule-shift">
      <span class="avatar">${escapeHtml(initials)}</span>
      <div>
        <strong>${escapeHtml(shift.name)}</strong>
        <span>${formatTimeRange(shift)}</span>
        <small>${escapeHtml(shift.position)}</small>
      </div>
    </div>
  `;
}

function getScheduleWeekDates(offset) {
  return Array.from({ length: 7 }, (_, index) => addDaysToDate(scheduleStartDate, offset * 7 + index));
}

function getShiftHours(shift) {
  const start = timeToMinutes(shift.start);
  let end = timeToMinutes(shift.end);
  if (end <= start) end += 1440;
  return (end - start) / 60;
}

function timeToMinutes(value) {
  const [hours, minutes] = value.split(':').map(Number);
  return hours * 60 + minutes;
}

function formatTimeRange(shift) {
  return `${formatTime(shift.start)} - ${formatTime(shift.end)}`;
}

function formatTime(value) {
  const [hourValue, minute] = value.split(':').map(Number);
  const marker = hourValue >= 12 ? 'PM' : 'AM';
  const hour = hourValue % 12 || 12;
  return `${hour}:${String(minute).padStart(2, '0')} ${marker}`;
}

function formatDateShort(value) {
  return new Date(`${value}T12:00:00`).toLocaleDateString([], { month: 'short', day: 'numeric' });
}

function renderCompass() {
  document.querySelector('#compassNotes').innerHTML = state.compassNotes
    .map((note) => `
      <article class="note">
        <strong>${escapeHtml(note.title)}</strong>
        <p class="subtle">${escapeHtml(note.body)}</p>
      </article>
    `)
    .join('');

  document.querySelector('#workflowList').innerHTML = sevenDayWorkflow
    .map((item) => `
      <article class="workflow-day">
        <div class="workflow-title">
          <strong>${escapeHtml(item.day)}</strong>
          <span class="badge medium">${escapeHtml(item.code)}</span>
        </div>
        ${workflowLine('Weekly', item.weekly)}
        ${workflowLine('7-Day', item.workflow)}
        ${workflowLine('Fresh Truck', item.freshTruck)}
        ${workflowLine('Nightly', item.nightly)}
      </article>
    `)
    .join('') + `
      <article class="workflow-day">
        <div class="workflow-title">
          <strong>Compliance Tuesday</strong>
          <span class="badge high">Required</span>
        </div>
        <ul>${complianceTuesdayTasks.map((task) => `<li>${escapeHtml(task)}</li>`).join('')}</ul>
      </article>
      <article class="workflow-day">
        <div class="workflow-title">
          <strong>Daily Activities</strong>
          <span class="badge low">Every Day</span>
        </div>
        <ul>${dailyActivities.map((task) => `<li>${escapeHtml(task)}</li>`).join('')}</ul>
      </article>
    `;
}

function workflowLine(label, value) {
  if (!value) return '';
  return `
    <div class="workflow-line">
      <span>${escapeHtml(label)}</span>
      <p>${escapeHtml(value)}</p>
    </div>
  `;
}

function renderMessages() {
  document.querySelector('#messageList').innerHTML = state.messages
    .map((message) => {
      const photo = findPhoto(message.photoId);
      return `
        <article class="message">
          <strong>${escapeHtml(message.from)}</strong>
          <span class="task-meta">${escapeHtml(message.time)}</span>
          <p class="subtle">${escapeHtml(message.body)}</p>
          ${photo ? photoThumb(photo) : ''}
        </article>
      `;
    })
    .join('');
}

function renderRoster() {
  document.querySelector('#rosterList').innerHTML = state.team
    .map((member) => `
      <article class="person">
        <strong>${escapeHtml(member.name)}</strong>
        <div class="task-meta">${escapeHtml(member.role)}</div>
        <div class="subtle">Best for ${escapeHtml(member.strength)}.</div>
      </article>
    `)
    .join('');
}

function capitalize(value) {
  return value.charAt(0).toUpperCase() + value.slice(1);
}

function formatDue(value) {
  if (value === isoToday) return 'today';
  return new Date(`${value}T12:00:00`).toLocaleDateString();
}

function escapeHtml(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}
